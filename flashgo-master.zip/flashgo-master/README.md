# Script Nuyul Aplikasi Flash-Go

<ul>
Untuk Penginstallan
<ul>
<li><code>apt update && apt upgrade</code></li>
<li><code>pkg install git python2 php</code></li>
<li><code>pip2 install mechanize requests</code></li>
<li><code>git clone https://github.com/B4N954N2-ID/flashgo</code></li>
<li><code>cd flashgo</code></li>
<li><code>php flashgo.php</code></li>
</ul>
<br />
<br />
<img src="https://github.com/B4N954N2-ID/flashgo/blob/master/Screenshot_20191012-061221.png" />
