<?php
############################################
# Author  : Sanz                           #
# YouTube : SANZ SOEKAMTI (Subscribe ^_^)  #
# GitHub  : https://github.com/B4N954N2-ID #
############################################

# Isi data dibawah ini tod!!
# Awas jangan sampai salah biar gak error ya bangsat ^_^

$user_name="xxxxxxxxxx";
$user_gaid= "xxxxxxxxx";
$user_token="xxxxxxxxxxxxxxx";
$user_id="xxxxxxxxxxxxxxxxxxxxxx";
$invite_code="xxxxxxxxxxxxxx";
$Bearer="xxxxxxxxxxxxxxxxxxxxxxxxxxx";

?>
